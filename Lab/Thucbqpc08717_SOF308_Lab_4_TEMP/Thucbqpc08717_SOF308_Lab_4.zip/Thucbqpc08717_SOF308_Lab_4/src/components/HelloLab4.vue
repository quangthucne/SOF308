<script>
export default {}
</script>

<template>
  <h1>Chào mừng Quang Thọt đã đến với VueJS</h1>
</template>

<style>
h1 {
  color: red;
}
</style>
