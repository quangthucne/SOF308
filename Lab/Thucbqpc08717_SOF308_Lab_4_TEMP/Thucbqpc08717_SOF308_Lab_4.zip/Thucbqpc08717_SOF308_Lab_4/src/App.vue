<script setup>
import { RouterLink, RouterView } from 'vue-router'
import HelloWorld from './components/HelloWorld.vue'
import Bai3 from './components/DaDoiTen.vue'
import HelloLab4 from './components/HelloLab4.vue'
import BaiBa from './components/BaiBa.vue'
import BaiBon from './components/BaiBon.vue'
</script>

<template>
  <HelloLab4 />
  <BaiBa />

  <BaiBon />
</template>

<style scoped></style>
